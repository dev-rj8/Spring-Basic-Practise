package com.udemycourse.spring.springscopebasic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringScopeBasicApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringScopeBasicApplication.class, args);
	}
}
